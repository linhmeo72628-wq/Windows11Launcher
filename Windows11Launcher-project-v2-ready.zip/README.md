# Windows11Launcher v2

Windows 11-style Android launcher prototype. v2 improves the desktop wallpaper, dark taskbar, centered Start/search, tray icons, Start menu, and basic shortcuts.

This is a launcher-style Android app; it does not replace Samsung system UI, lock screen, notification shade, or Android system settings.
