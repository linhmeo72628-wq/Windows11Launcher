package com.linhmeo.windows11launcher;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.content.*;
import android.net.Uri;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(new Desktop(this));
    }

    static class Desktop extends View {
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Calendar cal = Calendar.getInstance();
        boolean startOpen = false;
        int taskbarH = 72;

        Desktop(Context c) { super(c); p.setTypeface(Typeface.create("sans", Typeface.NORMAL)); setLayerType(View.LAYER_TYPE_SOFTWARE, null); }

        void fill(Canvas c, int color) { p.setColor(color); p.setStyle(Paint.Style.FILL); p.setShader(null); }
        void round(Canvas c,float l,float t,float r,float b,int color,float rad) { fill(c,color); c.drawRoundRect(l,t,r,b,rad,rad,p); }
        void text(Canvas c,String s,float x,float y,float size,int color) { fill(c,color); p.setTextSize(size); p.setTypeface(Typeface.create("sans",Typeface.NORMAL)); c.drawText(s,x,y,p); }
        void bold(Canvas c,String s,float x,float y,float size,int color) { fill(c,color); p.setTextSize(size); p.setTypeface(Typeface.create("sans",Typeface.BOLD)); c.drawText(s,x,y,p); }

        @Override protected void onDraw(Canvas c) {
            int w=getWidth(), h=getHeight();
            drawWallpaper(c,w,h-taskbarH);
            drawDesktopIcons(c);
            drawTaskbar(c,w,h);
            if(startOpen) drawStart(c,w,h);
        }

        void drawWallpaper(Canvas c,int w,int h) {
            LinearGradient bg = new LinearGradient(0,0,w,h,Color.rgb(4,23,50),Color.rgb(24,91,151),Shader.TileMode.CLAMP);
            p.setShader(bg); c.drawRect(0,0,w,h,p); p.setShader(null);
            // Abstract Windows-like blue ribbon, drawn locally so no external image is needed.
            p.setStyle(Paint.Style.FILL);
            p.setShader(new LinearGradient(w*.22f,h*.75f,w*.78f,h*.18f,0xff0b4fc5,0xff1686ff,Shader.TileMode.CLAMP));
            Path a=new Path(); a.moveTo(w*.18f,h*.76f); a.cubicTo(w*.30f,h*.34f,w*.45f,h*.10f,w*.72f,h*.22f); a.cubicTo(w*.55f,h*.27f,w*.42f,h*.45f,w*.36f,h*.72f); a.cubicTo(w*.31f,h*.86f,w*.24f,h*.88f,w*.18f,h*.76f); c.drawPath(a,p); p.setShader(null);
            p.setShader(new LinearGradient(w*.30f,h*.80f,w*.82f,h*.35f,0xff0a55d8,0xff42a5ff,Shader.TileMode.CLAMP));
            Path b=new Path(); b.moveTo(w*.30f,h*.83f); b.cubicTo(w*.42f,h*.42f,w*.60f,h*.22f,w*.86f,h*.40f); b.cubicTo(w*.67f,h*.39f,w*.52f,h*.58f,w*.46f,h*.86f); b.cubicTo(w*.41f,h*.95f,w*.34f,h*.93f,w*.30f,h*.83f); c.drawPath(b,p); p.setShader(null);
            p.setShader(new LinearGradient(w*.45f,h*.75f,w*.92f,h*.65f,0xff071a4a,0xff0c5bb8,Shader.TileMode.CLAMP));
            Path d=new Path(); d.moveTo(w*.46f,h*.87f); d.cubicTo(w*.55f,h*.54f,w*.68f,h*.43f,w*.96f,h*.62f); d.cubicTo(w*.75f,h*.56f,w*.64f,h*.72f,w*.58f,h*.91f); d.cubicTo(w*.53f,h*.97f,w*.49f,h*.94f,w*.46f,h*.87f); c.drawPath(d,p); p.setShader(null);
        }

        void drawDesktopIcons(Canvas c) {
            drawComputer(c,52,48); text(c,"Máy tính này",17,90,14,Color.WHITE);
            drawGear(c,52,140); text(c,"Trình cài đặt",16,181,14,Color.WHITE);
            drawChrome(c,52,235); text(c,"Chrome",31,276,14,Color.WHITE);
        }

        void drawComputer(Canvas c,float x,float y) {
            round(c,x-25,y-20,x+25,y+10,0xffc9d6e4,3); round(c,x-20,y-15,x+20,y+5,0xff21b5e8,1); fill(c,0xffc9d6e4); c.drawRect(x-4,y+10,x+4,y+17,p); c.drawRect(x-13,y+17,x+13,y+20,p);
        }
        void drawGear(Canvas c,float x,float y) { fill(c,0xffd9e3ef); c.drawCircle(x,y,15,p); fill(c,0xff152238); c.drawCircle(x,y,6,p); for(int i=0;i<8;i++){ double a=i*Math.PI/4; float x1=x+(float)Math.cos(a)*14,y1=y+(float)Math.sin(a)*14; c.save(); c.rotate(i*45,x1,y1); fill(c,0xffd9e3ef); c.drawRect(x1-3,y1-4,x1+3,y1+4,p); c.restore(); } }
        void drawChrome(Canvas c,float x,float y) { fill(c,0xffe64b3c); c.drawCircle(x,y,24,p); fill(c,0xffffd84d); c.drawArc(x-24,y-24, x+24,y+24,35,110,true,p); fill(c,0xff39a852); c.drawArc(x-24,y-24,x+24,y+24,145,110,true,p); fill(c,0xff4285f4); c.drawCircle(x,y,11,p); }

        void drawTaskbar(Canvas c,int w,int h) {
            int top=h-taskbarH;
            fill(c,0xe8191c23); c.drawRect(0,top,w,h,p);
            // centered group
            float cx=w/2f;
            drawWindows(c,cx-260,top+36,22);
            round(c,cx-210,top+14,cx-10,top+58,0xdd2a2f38,22);
            text(c,"⌕",cx-192,top+44,25,0xffe8edf5); text(c,"Tìm kiếm",cx-160,top+42,16,0xffd7dce5);
            drawWeather(c,cx+28,top+36);
            drawFolder(c,cx+78,top+36);
            drawGear(c,cx+128,top+36);
            // tray
            text(c,"⌃",w-170,top+44,22,0xffe9edf4); drawWifi(c,w-135,top+36); drawSpeaker(c,w-105,top+36); drawBattery(c,w-73,top+36);
            SimpleDateFormat time=new SimpleDateFormat("HH:mm",Locale.getDefault()); SimpleDateFormat date=new SimpleDateFormat("dd/MM/yyyy",Locale.getDefault());
            text(c,time.format(cal.getTime()),w-48,top+30,13,Color.WHITE); text(c,date.format(cal.getTime()),w-58,top+50,11,0xffd5d9df); drawBell(c,w-12,top+36);
        }
        void drawWindows(Canvas c,float x,float y,float s){ fill(c,0xff4cc2f1); c.drawRect(x-s,y-s,x-2,y-2,p); c.drawRect(x+2,y-s,x+s,y-2,p); c.drawRect(x-s,y+2,x-2,y+s,p); c.drawRect(x+2,y+2,x+s,y+s,p); }
        void drawWeather(Canvas c,float x,float y){ fill(c,0xffffb72b); c.drawCircle(x-5,y-5,7,p); fill(c,0xffdbe7f3); c.drawCircle(x+4,y,8,p); c.drawRect(x-4,y,x+12,y+7,p); }
        void drawFolder(Canvas c,float x,float y){ fill(c,0xffffc44f); c.drawRect(x-15,y-8,x+15,y+12,p); fill(c,0xffffd66b); c.drawRect(x-12,y-12,x-1,y-6,p); }
        void drawWifi(Canvas c,float x,float y){ p.setColor(0xffe9edf4); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(3); RectF r=new RectF(x-13,y-10,x+13,y+14); c.drawArc(r,220,100,false,p); r.inset(5,5); c.drawArc(r,220,100,false,p); p.setStyle(Paint.Style.FILL); c.drawCircle(x,y+9,2.5f,p); }
        void drawSpeaker(Canvas c,float x,float y){ fill(c,0xffe9edf4); Path q=new Path(); q.moveTo(x-12,y-4);q.lineTo(x-5,y-4);q.lineTo(x+4,y-12);q.lineTo(x+4,y+12);q.lineTo(x-5,y+4);q.lineTo(x-12,y+4);q.close();c.drawPath(q,p); }
        void drawBattery(Canvas c,float x,float y){ p.setColor(0xffe9edf4);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2);c.drawRect(x-10,y-8,x+10,y+8,p);p.setStyle(Paint.Style.FILL);c.drawRect(x-7,y-5,x+5,y+5,p);c.drawRect(x+10,y-3,x+13,y+3,p); }
        void drawBell(Canvas c,float x,float y){ fill(c,0xffe9edf4); c.drawCircle(x,y-2,7,p); c.drawRect(x-8,y-1,x+8,y+7,p); }

        void drawStart(Canvas c,int w,int h) {
            float cx=w/2f; float bottom=h-taskbarH-10; float top=Math.max(20,bottom-430); float left=cx-300, right=cx+300;
            round(c,left,top,right,bottom,0xf32a2e36,22);
            bold(c,"Bắt đầu",left+28,top+44,25,Color.WHITE);
            round(c,left+25,top+62,right-25,top+110,0xff3a3f48,13); text(c,"⌕",left+42,top+94,22,0xffe6ebf2); text(c,"Tìm kiếm ứng dụng, cài đặt...",left+76,top+93,14,0xffc4cbd5);
            bold(c,"Đã ghim",left+28,top+151,16,Color.WHITE);
            drawStartItem(c,left+55,top+205,"PC","Máy tính này"); drawStartItem(c,left+205,top+205,"⚙","Cài đặt"); drawStartItem(c,left+355,top+205,"C","Chrome");
            text(c,"Nguồn",left+28,bottom-52,15,0xffd9dee6); text(c,"⏻",right-70,bottom-50,22,Color.WHITE);
        }
        void drawStartItem(Canvas c,float x,float y,String icon,String label){ round(c,x-32,y-32,x+32,y+32,0xff343942,14); text(c,icon,x-11,y+8,20,Color.WHITE); text(c,label,x-38,y+57,12,0xffe3e7ed); }

        @Override public boolean onTouchEvent(MotionEvent e) {
            if(e.getAction()!=MotionEvent.ACTION_UP) return true;
            float x=e.getX(), y=e.getY(); int h=getHeight(), w=getWidth(); float cx=w/2f; int top=h-taskbarH;
            if(y>=top && x>cx-300 && x<cx+300){
                if(x>cx-240 && x<cx-10){ startOpen=false; invalidate(); return true; }
                if(x>cx-10 && x<cx+45){ startOpen=!startOpen; invalidate(); return true; }
                if(x>cx+60 && x<cx+105){ openFileManager(); return true; }
                if(x>cx+105 && x<cx+155){ openSettings(); return true; }
            }
            if(!startOpen && y<310){
                if(y<115){ openFileManager(); return true; }
                if(y<205){ openSettings(); return true; }
                openChrome(); return true;
            }
            if(startOpen){
                float left=cx-300, topStart=(h-taskbarH-10)-430;
                if(y>topStart+165 && y<topStart+270){
                    if(x>left+20 && x<left+140){ openFileManager(); return true; }
                    if(x>left+165 && x<left+300){ openSettings(); return true; }
                    if(x>left+320 && x<left+470){ openChrome(); return true; }
                }
            }
            return true;
        }
        void openChrome(){ try{ Intent i=new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com")); getContext().startActivity(i);}catch(Exception ignored){} }
        void openSettings(){ try{ getContext().startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS)); }catch(Exception ignored){} }
        void openFileManager(){ try{ Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("*/*"); i.addCategory(Intent.CATEGORY_OPENABLE); getContext().startActivity(i);}catch(Exception ignored){} }
    }
}
