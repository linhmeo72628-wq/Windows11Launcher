# Windows 11 Launcher

Windows 11-inspired Android launcher for Samsung phones.

## Build
Push to the `main` branch or run the `Build APK` GitHub Action manually.
The APK is uploaded as the `Windows11Launcher-debug` artifact.

This is a launcher app. It does not replace Samsung system UI, lock screen,
notification shade, or the real Android Settings app.
