package com.linhmeo.windows11launcher;

import android.app.*;
import android.os.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.content.*;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setFlags(1024,1024);
        setContentView(new Desktop(this));
    }

    static class Desktop extends View {
        Paint p = new Paint(3);
        boolean start = false;
        Calendar cal = Calendar.getInstance();

        Desktop(Context c) {
            super(c);
            p.setTypeface(Typeface.create("sans",0));
        }

        void text(Canvas c,String s,float x,float y,float size,int color) {
            p.setTextSize(size); p.setColor(color);
            p.setTypeface(Typeface.create("sans",0));
            c.drawText(s,x,y,p);
        }

        void box(Canvas c,float l,float t,float rr,float bb,int color,float rad) {
            p.setColor(color); c.drawRoundRect(l,t,rr,bb,rad,rad,p);
        }

        @Override protected void onDraw(Canvas c) {
            int w=getWidth(), h=getHeight();

            LinearGradient g = new LinearGradient(
                0,0,w,h,Color.rgb(8,35,75),Color.rgb(22,86,145),
                Shader.TileMode.CLAMP);
            p.setShader(g); c.drawRect(0,0,w,h,p); p.setShader(null);

            text(c,"PC",32,62,28,Color.WHITE);
            text(c,"Máy tính này",20,88,13,Color.WHITE);
            text(c,"⚙",42,145,28,Color.WHITE);
            text(c,"Trình cài đặt",20,170,13,Color.WHITE);
            text(c,"🌐",42,227,28,Color.WHITE);
            text(c,"Chrome",27,252,13,Color.WHITE);

            int bar=74;
            box(c,0,h-bar,w,h,0xffe9eef5,0);
            float cx=w/2f;
            box(c,cx-180,h-60,cx+180,h-15,0xfff7f9fc,22);
            text(c,"⌕",cx-160,h-30,25,0xff202124);
            text(c,"Tìm kiếm",cx-130,h-31,16,0xff5f6368);
            text(c,"⊞",cx-38,h-28,32,0xff1769aa);
            text(c,"☁",cx+10,h-28,22,0xff52606d);
            text(c,"▣",cx+55,h-28,22,0xffe8a317);
            text(c,"⚙",cx+92,h-28,22,0xff52606d);

            text(c,"⌁",w-175,h-37,22,0xff34495e);
            text(c,"🔊",w-145,h-37,18,0xff34495e);
            text(c,"▣",w-115,h-37,18,0xff34495e);
            text(c,new SimpleDateFormat("HH:mm",Locale.getDefault()).format(cal.getTime()),w-75,h-42,14,0xff263238);
            text(c,new SimpleDateFormat("dd/MM/yyyy",Locale.getDefault()).format(cal.getTime()),w-75,h-23,12,0xff263238);

            if(start) {
                box(c,cx-260,h-bar-420,cx+260,h-bar-10,0xf7f7fbff,18);
                text(c,"Bắt đầu",cx-225,h-bar-380,24,0xff202124);
                box(c,cx-225,h-bar-350,cx+225,h-bar-300,0xffeef2f7,12);
                text(c,"⌕  Tìm ứng dụng, cài đặt...",cx-205,h-bar-318,15,0xff667085);
                text(c,"Ứng dụng",cx-225,h-bar-255,16,0xff202124);
                text(c,"▣  Máy tính này",cx-210,h-bar-215,15,0xff202124);
                text(c,"⚙  Settings",cx-210,h-bar-175,15,0xff202124);
                text(c,"🌐  Chrome",cx-210,h-bar-135,15,0xff202124);
                text(c,"⏻  Tắt máy",cx+90,h-bar-45,15,0xff202124);
            }
        }

        @Override public boolean onTouchEvent(MotionEvent e) {
            if(e.getAction()!=MotionEvent.ACTION_UP) return true;
            float x=e.getX(), y=e.getY();
            int h=getHeight(), w=getWidth();
            float cx=w/2f;
            if(y>h-80 && x>cx-65 && x<cx+65) {
                start=!start; invalidate(); return true;
            }
            return true;
        }
    }
}
